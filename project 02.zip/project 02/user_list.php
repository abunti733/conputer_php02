<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/css/bootstrap.min.css" rel="stylesheet" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" />
    <link rel="stylesheet" href="admin_dashbord_style.css" />
	<link rel="stylesheet" type="text/css" href="css/jquery.DataTable.min.css" media="all" />
  <title>Document</title>
</head>
<body>
<?php 
include ("admin_dbcon.php");
if(!isset($_SESSION['user_login'])){
    header("location:admin_login_index.php");
}

if(isset($_POST['update'])){
    $user_id=$_POST['u_id'];
    $email=$_POST['email'];
    $mobile=$_POST['mobile'];
    $username=$_POST['username'];
    
    $update_query=mysqli_query(admin_dbcon,"UPDATE `form`SELECT `username`='$username', `email`='$emil',  `mobile`='$mobile'WHERE `id`='$user_id'");
    if($update_query){
        echo '
        <script>
        alert("successfully updated data");
        window.location.href="admin_index.php?page=user_list";
        
        
        </script>
        
        
        ';
        $email=false;
        $mobile=false;
        $username=false;
        
        
        
        
    }
}

?>

<div class="dasboard">
    <h1>Dashboard <small>Statistics Overview</small></h1>
    <div class="p-2" style="background:#f5f5f5;"><a href="admin_index.php?page=user_list">User List</a></div>
</div>
<div class="user_list">
<table id="myTable" class="display">
    <thead>
        <tr>
            <th>Id</th>
            <th>Username</th>
            <th>Email</th>
            <th>Mobile</th>
            <th>Action</th>
        </tr>
    </thead>
    <tbody>
      
    <?php
      $select = mysqli_query($admin_dbcon , "SELECT * FROM `from`");
      while($rows=mysqli_fetch_assoc($select)){
    ?>
            <tr>
                <td><?php echo $rows['id'] ?></td>
                <td><?=$rows['username']?></td>
                <td><?=$rows['email']?></td>
                <td><?=$rows['mobile']?></td>
               
      <td>
                <div class="dropdown">
  <button class="btn btn-success dropdown-toggle" type="button" id="dropdownMenuButton1" data-bs-toggle="dropdown" aria-expanded="false">
    Action
  </button>
  <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton1">
    <li><a class="dropdown-item" style="color:#076539" href="profile_view.php?u_id=<?=base64_encode($rows['id'])?>">View</a></li>
    <li><a class="dropdown-item" style="color:blue" href="#" data-bs-toggle="modal" data-bs-target="#exampleModal<?=$rows['id'];?>">Edit</a></li>
   <li><a class="dropdown-item" style="color:red" onclick="return confirm('Are you sure delete this data!')" target="_blank"href="delete.php?&u_del_id=<?=base64_encode($rows['id'])?>">Delete</a></li>
   
   
	
	
  </ul>
</div>
<!-- edit section start -->

<!-- Modal -->  
<div class="modal fade" id="#exampleModal<?=$rows['id'];?>" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="staticBackdropLabel">user update form</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <form method="POST" enctype="multipart/form-data">
      <div class="modal-body">
     <div class="row"> 
        <div class="col">  
           <div class="input-group mb-2"> 
            <label for="" class="form-label">username</label>
            <input type="hidden" class="form-control" name="u_id" id="u_id" value="<?=$rows['u_id']?>">
            <input type="text" placeholder="username"class="form-control" name="username" id="username" value="<?=$rows['username']?>">
           </div>

           <div class="input-group mb-2"> 
            <input type="text" placeholder="emil" class="form-control" name="email" id="email" value="<?=$rows['email']?>">
           </div>


           <div class="input-group mb-2"> 
            <input type="text" placeholder="mobile" class="form-control" name="mobile" id="mobile" value="<?=$rows['mobile']?>">
           </div>


        </div>
     </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">cancel</button>
        <input type="text" name="update" class="btn btn-primary" value="update">
      </div>
      </form>
    </div>
  </div>
</div>

<!-- edit section end -->
            
            
            
            
            
            
            </td>
               
            </tr>
    <?php
      }
    ?>
    </tbody>
    
</table>
</div>


    <!-- /#page-content-wrapper -->

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/js/bootstrap.bundle.min.js"></script>
	
	
  
   <script>
        var el = document.getElementById("wrapper");
        var toggleButton = document.getElementById("menu-toggle");

        toggleButton.onclick = function () {
            el.classList.toggle("toggled");
        };
    </script>


	<script type="text/javascript" src="js/jquery-3.7.1.js"></script>
	<script type="text/javascript" src="js/jquery.DataTable.min.js"></script>
  




<script type="text/javascript">

$(document).ready( function () {
    $('#myTable').DataTable();
} );


</script>


</body>
</html>