<?php
session_start();
include ("admin_dbcon.php");
if(!isset($_SESSION['user_login'])){
    header("location:admin_login_index.php");
}

if(isset($_POST['update'])){
    $user_id=$_POST['u_id'];
    $email=$_POST['email'];
    $mobile=$_POST['mobile'];
    $username=$_POST['username'];
    
    $update_query=mysqli_query(admin_dbcon,"UPDATE `form`SELECT `username`='$username', `email`='$emil',  `mobile`='$mobile'WHERE `id`='$user_id'");
    if($update_query){
        echo '
        <script>
        alert("successfully updated data");
        window.location.href="admin_index.php?page=user_list";
        
        
        </script>
        
        
        ';
        $email=false;
        $mobile=false;
        $username=false;
        
        
        
        
    }
}
?>