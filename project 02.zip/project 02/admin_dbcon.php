<?php 
$hostname = "localhost";
$usernamex = "root";
$password = "";
$database_name = "register";
$admin_dbcon=mysqli_connect($hostname , $usernamex , $password , $database_name);

?>