<?php 
include 'admin_dbcon.php';
session_start();
$admission_id=base64_decode($_GET)['admission_id'];
if(admission_id){
	$admission_id_query=mysqli_query($admin_dbcon,"SELECT `student_name`, `Roll`, `division`, `dristrict`, `thana`, `post_office`, `Village`, `religion`, `job_title`, `birth_certificate`, `gender`, `register_type`, `email`, `father_name`, `mother_name`, `relation_guardian`, `occupation_guardian`, `student_number`, `course`, `session`, `guardian_number`, `blood_group`, `admission_time`, `addmission_form`, `regi_time`, `status` FROM `admission` WHERE `id`='admission_id'");
	if(isset($_POST['register'])){
	$Roll=$_POST['Roll'];
	$student_Name=$_POST['student_Name'];
	$student_number=$_POST['student_number'];
	$Course=$_POST['Course'];
	$Session=$_POST['Session'];
	$Father_Name=$_POST['Father_Name'];
	$Mother_Name=$_POST['Mother_Name'];
	$Guardian_Mobile=$_POST['Guardian_Mobile'];
	$Division=$_POST['Division'];
	$District=$_POST['District'];
	$Thana=$_POST['Thana'];
	$Post_Office=$_POST['Post_Office'];
	$Village=$_POST['Village'];
	$Religion=$_POST['Religion'];
	$Job Title=$_POST['Job Title'];
	$Date Of Birth=$_POST['Date Of Birth'];
	$Nid/Birth Certificte=$_POST['Nid/Birth Certificte'];
	$Blood Group=$_POST['Blood Group'];
	$Gender=$_POST['Gender'];
	$Register Type=$_POST['Register Type'];
	$Email=$_POST['Email'];





	}
	$_SESSION_id['admission_id']=$admission_id;
    header('location: admin_index.php?page=table_form');
}


?>


<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<link rel="stylesheet" href="table_style.css">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
	<title>Document</title>

	<div class="container">
		<div class="row">
			<div class="header">
				<div class="logo">
					<img src="profile_picture.png">
				</div>
				<div class="main_header">
				<h2>FUTURE  COMPUTER  TRANING  INSTITUTE</h2>
				<h3>ফিউচার কম্পিউটার ট্রেনিং ইনস্টিটিউট</h3>
				<h4>Institute Code: 44047 EST: 2017</h4>
				<span>Old Bus Stand , Al-Arafah Bank 3rd Floor , Madaripur</span><br/>
				<span>CONTACT : +880 01954496280  WEBSITE : https://futurecomputer.net/</span>
				
				</div>
				<div class="logo">
					<img src="download.jpg">
				</div>
			
			</div>
			<div class="main_part">
				<h3>Admission Form</h3>
				<div class="head">
				<div class="col">
					<h4>User ID :4405399</h4>
				</div>
				<div class="col">
					<h4>Admission Date: 01-10-2024</h4>
				</div>
				</div>
				<div class="table_img">
					<div class="img_part">
						<img src="avator.png">
					</div>
					<div class="table_part">
					<table border="1" cellspacing="0">
					<tr>
						<td>Roll</td>
						<td>4402399</td>
					
					</tr>
					
					<tr>
						<td>student_Name</td>
						<td>aklima akter</td>
					
					</tr>
					<tr>
						<td>student_number</td>
						<td>01954496280</td>
					
					</tr>
					<tr>
						<td>Course</td>
						<td>Computer Office Application</td>
					
					</tr>
					<tr>
						<td>Session</td>
						<td>January - September</td>
					
					</tr>
					</table>
					</div>
				
				
				</div>
			</div>
			<div class="parsonal_info">
				<table border="1" cellspacing="0">
					<tr class="title_td">
						<td>Father_Name</td>
						<td>Md Nur_Uddin Dhali</td>
						
					</tr>
				<tr>
						<td>Mother_Name</td>
						<td>Joygun Nesa</td>
						
					</tr>
					<tr>
						<td>Guardian_Mobile</td>
						<td>+880 1323630054</td>
						
					</tr>
					<tr>
						<td>Division</td>
						<td>Dhaka</td>
						
					</tr>
					<tr>
						<td>District</td>
						<td>Madaripur</td>
						
					</tr>
					<tr>
						<td>Thana</td>
						<td>Madaripur Sadar</td>
						
					</tr>
					<tr>
						<td>Post_Office</td>
						<td>Goatmazi</td>
						
					</tr>
					<tr>
						<td>Village</td>
						<td>Jhikurhati</td>
						
					</tr>
					
				</table>
			
			<table border="1" cellspacing="0">
					<tr>
						<td>Religion</td>
						<td>Islam</td>
						
					</tr>
				<tr>
						<td>Job Title</td>
						<td>Student</td>
						
					</tr>
					<tr>
						<td>Date Of Birth</td>
						<td>01-01-2003</td>
						
					</tr>
					<tr>
						<td>Nid/Birth Certificte</td>
						<td>201547895</td>
						
					</tr>
					<tr>
						<td>Blood Group</td>
						<td>A+</td>
						
					</tr>
					<tr>
						<td>Gender</td>
						<td>Male</td>
						
					</tr>
					<tr>
						<td>Register Type</td>
						<td>No Register</td>
						
					</tr>
					<tr>
						<td>Email</td>
						<td>aklima2023@gmail.com</td>
						
					</tr>
				</table>
			
			
			</div>
			<div class="content">
				<ol>
					<li><i class="fa fa-hand-o-right" aria-hidden="true"></i>ভর্তি ফি কোনো মতেই ফেরত যোগ্য নয় ।</li>
					<li><i class="fa fa-hand-o-right" aria-hidden="true"></i>ছাত্র / ছাত্রীদের ব্যাক্তিগত কারণ বসত কোর্স টি সম্পর্ণ না করতে পারলে প্রতিষ্ঠান ধায়ী থাকবে না ।</li>
					<li><i class="fa fa-hand-o-right" aria-hidden="true"></i>ভর্তির সময় মিনিমান ৭০% ফি  দিতে হবে । বাকি টাকা ১ মাস ১০ দিনের মধ্যে জমা দিতে হবে ।<li>
					<li><i class="fa fa-hand-o-right" aria-hidden="true"></i>নির্ধারিত সময়ের মধ্যে টানা না দিতে পারলে ৫০০ টাকা জরিমানা দিতে হবে ।</li>
					<li><i class="fa fa-hand-o-right" aria-hidden="true"></i>ভর্তি ফি ও আইডি কার্ড বাবদ ২০০ টাকা প্রদান করতে হবে ।</li>
					<li><i class="fa fa-hand-o-right" aria-hidden="true"></i>রেজিষ্ট্রেশন ফি বাবদ ৬৫০ টাকা রেজিষ্ট্রেশনের সময় দিতে হবে ।</li>
					<li><i class="fa fa-hand-o-right" aria-hidden="true"></i>ক্লাসে প্রবেশ করার সময় অবশ্যেই উপস্থিত মেশিন এ ফিঙ্গারপ্রিন্ট দিয়ে প্রবেশ করতে হবে ।<li>
					<li><i class="fa fa-hand-o-right" aria-hidden="true"></i>প্রতিষ্ঠানের সকল নিয়ম মেনে ক্লাস করতে হবে ।</li>
					<li><i class="fa fa-hand-o-right" aria-hidden="true"></i>পরিক্ষা না দিলে কোনো শিক্ষার্থী লাইভটাইম সবিধা পাবে না ।</li>
					
				
				
				</ol>
			
			
			
			</div>
		<div class="content_1">
			<p>I assure ...............................................that i will abide by all the rules and regulations of FCTI . i will not to do any irregularity . In case of any irregularity , the authority may take any legal action against me.</p>
		</div>
		<div class="signature">
			<div class="student_signature">
				<span>Student Signature</span>
			</div>
			<div class="director_signature">
				<span>Director Signature</span>
			</div>
		
		
		</div>
	</div>

	</div>
	
	

</body>
</html>