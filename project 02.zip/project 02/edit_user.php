<?php
include ("admin_dbcon.php");

if(isset($_POST['update'])){
    $email=$_POST['email'];
    $mobile=$_POST['mobile'];
    $status=$_POST['status'];
    
    $update_query=mysqli_query(admin_dbcon,"UPDATE `from`SELECT `email`='$email', `mobile`='$mobile',  `status`='$status'WHERE `id`='$user_id'");
    if($update_query){
        echo '
        <script>
        alert("successfully updated data");
        window.location.href="admin_index.php?page=user_list";
        
        
        </script>
        
        
        ';
        $email=false;
        $mobile=false;
        $status=false;
        
        
        
        
    }
}



?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="./css/admin_dashboard.css">
	<link rel="stylesheet" href="css/jquery.dataTables.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    
    <title>edit data</title>
</head>
<body>
    <form method="post">
    <div class="container"> 
        <div class="row"> 
            <h1> User Edit form</h1>
            <div class="col-sm-12 col-md-6 col-lg-6 col-xl-4 col-xxl-4 mb-2">
                
            <div class="input-group-mp-3"> 
                    <span class="input_group_text" id="basic-addon1"><i class="fa fa-phone"></i></span>
                    <input name="mobile" type="text" class="form-control" placeholder="Mobile" aria-describedby="basic-addon1" value="<?$rows['mobile']?>">


                </div>


                <div class="input-group-mp-3"> 
                    <span class="input_group_text" id="basic-addon1"><i class="fa fa-phone"></i></span>
                    <input name="Email" type="text" class="form-control" placeholder="Email" aria-describedby="basic-addon1" value="<?$rows['Email']?>">


                </div>


                <div class="input-group-mp-3"> 
                    <span class="input_group_text" id="basic-addon1"><i class="fa fa-unlock-alt"></i></span>
                    <input name="status" type="text" class="form-control" placeholder="status" aria-describedby="basic-addon1" value="<?$rows['status']?>">


                </div>
            <input type="submit" class="btn btn-primary"name="update" value="Update">


            </div>
        </div>
    </div>


    </form>
    <script src="js/bootstrap.min.js"></script>
</body>
</html>