<?php
$admin_dbcon = mysqli_connect("localhost" , "root" , "" , "register");

if(isset($_POST['submit'])){
$name = $_POST['course'];

$insert = mysqli_query($admin_dbcon , "");
echo "ok";
}


?>