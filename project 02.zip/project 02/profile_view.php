<?php
require("admin_dbcon.php");
$u_id=base64_decode($_GET['u_id']);
$data_select=mysqli_query($admin_dbcon,"SELECT * FROM `from` WHERE `id`='$u_id'");
$data_fetch=mysqli_fetch_assoc($data_select);
echo $data_fetch['mobile'];
echo $data_fetch['email'];
echo $data_fetch['username'];

?>
