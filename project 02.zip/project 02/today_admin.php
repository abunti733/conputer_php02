<?php
include 'admin_dbcon.php';
$query="SELECT * FROM `admission`";
$select= mysqli_query($admin_dbcon,$query);


?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/css/bootstrap.min.css" rel="stylesheet" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" />
    <title>Bootstap 5 Responsive Admin Dashboard</title>
</head>

<body>
	<h1 class="" style="color:crimson;  text-align:center;"><i class="fas fa-tachometer-alt"></i>Dashboard <small>Statistcss Overiew</small></h1>

            <div class="container-fluid px-4">
                <div class="row g-3 my-2">
						<div class="row">
  <div class="col-sm-3">
    <div class="card"style="background:crimson; margin-bottom:8px;">
      <div class="card-body">
        <i class="fas fa-users" style="font-size:30px; color:#fff"></i>
	   <h1 class=""style="color:#fff;">499</h1>
        <p class="card-text"style="color:#fff;">All Students</p>
        
      </div>
    </div>
  </div>
  <div class="col-sm-3">
    <div class="card"style="background:crimson;margin-bottom:8px;">
      <div class="card-body">
		 <i class="fas fa-users" style="font-size:30px; color:#fff"></i>
		<h1 class=""style="color:#fff;">493</h1>
        <p class="card-text"style="color:#fff;">Offline Students</p>
       
      </div>
    </div>
  </div>
  <div class="col-sm-3">
    <div class="card"style="background:crimson;margin-bottom:8px;">
      <div class="card-body">
         <i class="fas fa-users" style="font-size:30px; color:#fff"></i>
		<h1 class=""style="color:#fff;">493</h1>
        <p class="card-text"style="color:#fff;">Online Student</p>
        
      </div>
    </div>
  </div>
  <div class="col-sm-3">
    <div class="card"style="background:crimson;margin-bottom:8px;">
      <div class="card-body">
        <i class="fas fa-users" style="font-size:30px; color:#fff"></i>
		<h1 class=""style="color:#fff;">499</h1>
        <p class="card-text"style="color:#fff;">Total Account</p>
        
      </div>
    </div>
  </div>
  



  <!-- table start -->
<div  id="table-container" style="margin: 50px 0px;">
	  <table class="table table-striped">
		<thead style="background:crimson; color:white;">
			<tr>
				<th class="th">ID</th>
				<th class="th">Name</th>
				<th class="th">Father Name</th>
				<th class="th">Phone Number</th>
				<th class="th">Course</th>
				<th class="th">Session</th>
                <th class="th">Registration Time</th>
                <th class="th">Photo</th>
                <th class="th">Action</th>
			</tr>
		</thead>
		<tbody style="line-height: 50px;">
		<?php
		while($data=mysqli_fetch_assoc($select)){
		 ?>
			<tr>
				<td class="td"><?php echo $data['id'];?></td>
				<td class="td"><?php echo $data['student_name'];?></td>
				<td class="td"><?php echo $data['father_name'];?></td>
				<td class="td"><?php echo $data['student_number'];?></td>
                <td class="td"><?php echo $data['course'];?></td>
                <td class="td"><?php echo $data['session'];?></td>
                <td class="td"><?php echo $data['regi_time'];?></td>
                <td class="td"><img height="60px" width="60px" src="<?php echo $data['photo'];?>" alt=""></td>
                <td class="td"><ul><li style="border: none; padding: 0px 17px; background: crimson;color: white;font-size: 20px;"><div id="action" onclick="submenutwo()"><span>action</span> <div class="icon"><i style="text-align: right;" class="fa-solid fa-caret-down"></i></div></div>
                    <ul id="ul" style="display: none;">
                        <li style="border-bottom: 1px solid black;border-top: 1px solid black;background: crimson;text-align: center;"><a href="admin_index.php?page=admin_register_login_form" style="text-decoration: none;color: white;">View</a></li>
                        <li style="border-bottom: 1px solid black;background:crimson;text-align: center;"><a href="student_data_delete.php?id=<?php echo $data['id']; ?>"  style="text-decoration: none;color: white;">Remove</a></li>
                    </ul>
                </li></ul>
                </td>
                <script>
                    function submenutwo() {
  var y = document.getElementById('ul');
  if (y.style.display === 'none') {
    y.style.display = 'block';
  } else {
    y.style.display = 'none';
  }
}
                </script>
                <style>
                    #action{
                        display: flex;
                        justify-content: space-between;
                        line-height: 45px;
                        text-decoration: none;
                        color: white;
                    }
                    #ul{
                        width: 147px;
                        margin-left: -47px;
                        padding-top: 10px;
                        margin-top: -5px;
                        position: absolute;
                    }
                </style>
			</tr>
			<?php }?>
		</thead>
	  </table>
   </div>
<!-- table end -->

<script src="js/bootstrap.min.js"></script>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="//cdn.datatables.net/1.10.25/css/jquery.dataTables.min.css" rel="stylesheet">
  <script src="https://code.jquery.com/jquery-3.6.0.min.js" ></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/js/bootstrap.min.js" ></script>
  <script src="//cdn.datatables.net/1.10.25/js/jquery.dataTables.min.js"></script>
  <script>
  $(document).ready( function () {
		$('.table').DataTable();
  });
  </script>






</div>
   </div>
	</div>
</body>
</html>