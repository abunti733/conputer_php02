-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 12, 2023 at 04:09 PM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 7.4.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `register`
--

-- --------------------------------------------------------

--
-- Table structure for table `admission`
--

CREATE TABLE `admission` (
  `id` int(100) NOT NULL,
  `student_name` varchar(90) NOT NULL,
  `Roll` int(20) NOT NULL,
  `division` varchar(45) NOT NULL,
  `dristrict` varchar(55) NOT NULL,
  `thana` varchar(35) NOT NULL,
  `post_office` varchar(32) NOT NULL,
  `Village` varchar(62) NOT NULL,
  `religion` varchar(55) NOT NULL,
  `job_title` varchar(62) NOT NULL,
  `birth_certificate` varchar(46) NOT NULL,
  `gender` varchar(41) NOT NULL,
  `register_type` varchar(81) NOT NULL,
  `email` varchar(75) NOT NULL,
  `father_name` varchar(80) NOT NULL,
  `mother_name` varchar(70) NOT NULL,
  `guardian` varchar(60) NOT NULL,
  `relation_guardian` varchar(50) NOT NULL,
  `occupation_guardian` varchar(45) NOT NULL,
  `dob` varchar(40) NOT NULL,
  `student_number` varchar(35) NOT NULL,
  `course` varchar(50) NOT NULL,
  `session` varchar(40) NOT NULL,
  `guardian_number` varchar(30) NOT NULL,
  `blood_group` varchar(25) NOT NULL,
  `photo` varchar(100) NOT NULL,
  `admission_time` varchar(20) NOT NULL,
  `addmission_form` varchar(65) NOT NULL,
  `regi_time` varchar(15) NOT NULL,
  `status` varchar(26) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admission`
--

INSERT INTO `admission` (`id`, `student_name`, `Roll`, `division`, `dristrict`, `thana`, `post_office`, `Village`, `religion`, `job_title`, `birth_certificate`, `gender`, `register_type`, `email`, `father_name`, `mother_name`, `guardian`, `relation_guardian`, `occupation_guardian`, `dob`, `student_number`, `course`, `session`, `guardian_number`, `blood_group`, `photo`, `admission_time`, `addmission_form`, `regi_time`, `status`) VALUES
(0, 'aklima Akter', 0, '', '', '', '', '', '', '', '', '', '', '', 'Md: Nur-uddin', 'Mother: name', 'Md Jamal', 'Brother', 'Busniess', '', '017896375074', 'php', 'january_jun', '0186358724', '', 'images.png', '', '', '', ''),
(1, 'aklima Akter', 0, '', '', '', '', '', '', '', '', '', '', '', 'Md: Nur-uddin', 'Mother: name', 'Md Jamal', 'Brother', 'Busniess', '14-1-1990', '017896375074', 'html', 'July_December', '0186358724', 'B+', 'images2.png', '14-5-2323', '', '14-5-2323', '1'),
(17, 'Sadia', 0, '', '', '', '', '', '', '', '', '', '', '', 'Md Nur_uddin Dhali', 'Mrs Joygun nesa', 'Father', 'baba', 'Farmar', '15-01-2000', '01786534211', 'Js', 'january_Jun', '01478965214', 'O+', 'images.png', '15-02-2024', '', '15-02-2024', '1'),
(18, 'Sadia', 0, '', '', '', '', '', '', '', '', '', '', '', 'Md Nur_uddin Dhali', 'Mrs Joygun nesa', 'Father', 'baba', 'Farmar', '15-01-2000', '01786534211', 'Js', 'january_Jun', '01478965214', 'O+', 'images.png', '15-02-2024', '', '15-02-2024', '1');

-- --------------------------------------------------------

--
-- Table structure for table `from`
--

CREATE TABLE `from` (
  `id` int(70) NOT NULL,
  `username` varchar(50) NOT NULL,
  `email` varchar(40) NOT NULL,
  `mobile` varchar(11) NOT NULL,
  `password` varchar(30) NOT NULL,
  `reg_time` varchar(20) NOT NULL,
  `status` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `from`
--

INSERT INTO `from` (`id`, `username`, `email`, `mobile`, `password`, `reg_time`, `status`) VALUES
(13, 'sadia', 'sadia@gamil.com', '01786375074', 'aklima123456', '11-14-2023,03:42:51 ', 'active'),
(14, 'josna', 'josna@hamil.com', '0158796544', '123456789', '11-20-2023,07:49:42 ', 'Active'),
(15, 'aklima', 'aklimaweb2023@gmail.com', '01786375074', 'aklima2023', '11-29-2023,08:40:47 ', 'Active');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admission`
--
ALTER TABLE `admission`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `from`
--
ALTER TABLE `from`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admission`
--
ALTER TABLE `admission`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `from`
--
ALTER TABLE `from`
  MODIFY `id` int(70) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
