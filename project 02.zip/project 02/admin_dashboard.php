<?php 




?>

<!-- <div class="dasboard">
    <h1>Dashboard <small>Statistics Overview</small></h1>
    <div class="p-2" style="background:#f5f5f5;"><a href="admin_index.php?page=admin_dashboard">Dashboard</a></div>
</div> -->
<?php
include 'today_admin.php';

?>


